ELAN EVENTS — WEDDING PLANNER WEBSITE
=====================================

PROJECT CONTENTS
- index.html       Main website structure and content
- css/style.css    Responsive styling, layout and visual design
- js/script.js     Mobile navigation and contact form interaction

HOW TO RUN
1. Extract the ZIP file.
2. Open the wedding_planner_website folder.
3. Double-click index.html to open it in your browser.
4. For editing, open the folder in Visual Studio Code.

CUSTOMIZE BEFORE SUBMISSION
- Replace "Amira Ben Salem" with your own name/profile.
- Update the education, experience, skills and contact details.
- Replace the sample project names and photos with your own work.
- Update the email and social media links.
- The images and Google Fonts are loaded online, so an internet connection is needed.

IMPORTANT
The contact form is a front-end demo. It validates the fields and shows a confirmation,
but it does not send an email. To receive real messages, connect it to a backend
or a form service.

TECHNOLOGIES
HTML5 · CSS3 · JavaScript · Visual Studio Code
